﻿namespace OnlineShop.Models
{
    public enum AdStatus
    {
        Open,
        Closed
    }
}
